﻿using System;
using System.Windows.Forms;

namespace F22BA067_slot
{
    public partial class Form1 : Form
    {
        Timer timer1;
        Timer timer2;
        Timer timer3;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//スタートボタン
        {
            timer1 = new Timer();
            timer1.Interval = 100;
            timer1.Tick += Timer1_Tick;
            timer1.Start();

            timer2 = new Timer();
            timer2.Interval = 10;
            timer2.Tick += Timer2_Tick;
            timer2.Start();

            timer3 = new Timer();
            timer3.Interval = 50;
            timer3.Tick += Timer3_Tick;
            timer3.Start();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            //左リール
            var random = new Random();
            int num = random.Next(0, 9);
            label1.Text = num.ToString();
        }

        private void Timer2_Tick(object sender, EventArgs e)
        {
            //中リール
            var random = new Random();
            int num = random.Next(0, 9);
            label2.Text = num.ToString();
        }

        private void Timer3_Tick(object sender, EventArgs e)
        {
            //右リール
            var random = new Random();
            int num = random.Next(0, 9);
            label3.Text = num.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //第一停止ボタン
            timer1.Dispose();
            CheckWin();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //第二停止ボタン
            timer2.Dispose();
            CheckWin();
        }

        private void button4_Click(object sender, EventArgs e)
        { 
            //第三停止ボタン
            timer3.Dispose();
            CheckWin();
        }

        private void CheckWin()
        {
            // 当たり判定を行う関数
            if (label1.Text == label2.Text && label2.Text == label3.Text)
            {
                label4.Text = "当たり！";
            }
            else
            {
                label4.Text = "";
            }
        }
    }
}