/*　プログラム名：数当てプログラムStep4
 *  プログラムの説明：条件文を利用して、当たり以外のゲーム終了キー『999』を設定します。
 *  				　『999』を入力した場合に、繰り返し処理を抜けてゲームを終了します。
 *  作成者：西山　拓人
 *  作成日：2024年4月11日
 */


package jp.co.f1.app.numberhit;
import java.util.Scanner;

public class NumberHitS04 {

	public static void main(String[] args) {
		
		//入力受付の準備
		Scanner sc = new Scanner(System.in);
		
		//タイトル表示
		System.out.println("ゲーム開始(正解数字：5");
		System.out.println("");
		
		//正解数字の初期化
		int answerNum = 5;
		
		while (true) {
			//入力を促すメッセージ
			System.out.print("　0から9までの予想の数字を入力>>");
			
			//予想数字の入力を受け取り変数num1を初期化
			int playerNum = sc.nextInt();
			
			//入力に応じた出力の条件分岐
			if (playerNum == answerNum) {
				System.out.println("　　→！！大当たり！！");
				System.out.println();
				break;
			} else if (playerNum == 999){
				System.out.println("　　→999が入力されたためゲームを終了します。");
				System.out.println();
				break;
		    } else if (playerNum >answerNum) {
				System.out.println("　　→正解数字は" + playerNum + "より小さいです。");
				System.out.println();
			} else {
				System.out.println("　　→正解数字は" + playerNum + "より大きいです");
				System.out.println();
			}
		}
		
		//scannerを閉じる
		sc.close();
		
		//終了メッセージ出力
		System.out.println("ゲーム終了");
		
	}

}
