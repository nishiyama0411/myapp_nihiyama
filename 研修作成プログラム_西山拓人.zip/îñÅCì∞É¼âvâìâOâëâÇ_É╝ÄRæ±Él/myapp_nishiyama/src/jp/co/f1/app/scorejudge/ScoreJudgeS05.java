/*　プログラム名：点数評価プログラムStep5
 *  プログラムの説明：評価した点数の中から最高点と最低点を求める処理を追加します。
 *  				  繰り返し処理が終了した後に、各情報をコンソール画面に表示します。
 *  作成者：西山　拓人
 *  作成日：2024年4月16日
 */

package jp.co.f1.app.scorejudge;
import java.util.Scanner;
public class ScoreJudgeS05 {

	public static void main(String[] args) {

		//標準入力の準備
		Scanner sc = new Scanner(System.in);
		
		//平均点と合計点と人数を格納する変数の初期化
		int sam = 0;
		double ave = 0;
		int count = 0;
		
		//maxScoreとminScoreの初期化
		int maxScore = -1;
		int minScore = 101;
		
		//タイトル
		System.out.println("---点数評価プログラム開始---");

		while (true) {

			//入力を促すメッセージ
			System.out.println();
			System.out.print("＞");

			//入力を変数scoreに代入
			String scoreStr = sc.nextLine();
			
			//"q"だった場合ループを抜ける
			if (scoreStr.equals("q")) {
				System.out.println("qが入力されたため、終了します。");
				break;
			}
			
			//Stringをintに変換して代入
			int score = Integer.parseInt(scoreStr);
			

			//点数評価
			if (score < 0 || score > 100) {
				System.out.println("→範囲外の数字が入力されました。再度、0から100までの数字を入力してください。");
				//平均と合計が変動しないため
				continue;
			} else if (score <= 59) {
				System.out.println("→評価Fです。");
			} else if (score <= 69) {
				System.out.println("→評価Dです。");
			} else if (score <= 79) {
				System.out.println("→評価Cです。");
			} else if (score <= 89) {
				System.out.println("→評価Bです。");
			} else if (score <= 100) {
				System.out.println("→評価Aです。");
			}
			
			//人数をカウント
			count++;
			
			//合計点と平均点を代入
			sam += score;
			ave = sam / count;
			
			//最高得点と最低得点を代入
			if (score > maxScore) {
				maxScore = score;
			}
			if (score < minScore) {
				minScore = score;
			}
		}
		
		//サマリー表示
		System.out.println();
		System.out.println("----------サマリー----------");
		
		//表示内容を決める処理
		if (count == 0) {
			System.out.println("評価された人数が0名のためサマリーは表示しません。");
		} else {
			System.out.println(count + "名の成績を評価しました。");
			System.out.println("　最高得点は" + maxScore + "点でした。");
			System.out.println("　最低得点は" + minScore + "点でした。");
			System.out.println("　合計点は" + sam + "点でした。");
			System.out.println("　平均点は" + ave + "点でした。");
		}
		
		System.out.println("----------------------------");

		sc.close();
		//終了画面
		System.out.println();
		System.out.println("---点数評価プログラム終了---");

	}

}
