/*　プログラム名：数当てプログラムStep5
 *  プログラムの説明：「条件文」を利用して「キーボードから入力した予想数字」の範囲チェックを行います。
 *  				   範囲外の場合はEclipseのコンソール画面にメッセージを表示します。
 *  作成者：西山　拓人
 *  作成日：2024年4月12日
 */


package jp.co.f1.app.numberhit;
import java.util.Scanner;

public class NumberHitS05 {

	public static void main(String[] args) {
		
		//入力受付の準備
		Scanner sc = new Scanner(System.in);
		
		//タイトル表示
		System.out.println("ゲーム開始(正解数字：5)");
		System.out.println("");
		
		//正解数字の初期化
		int answerNum = 5;
		
		while (true) {
			//入力を促すメッセージ
			System.out.print("　0から9までの予想の数字を入力>>");
			
			//予想数字の入力を受け取り変数num1を初期化
			int playerNum = sc.nextInt();
			
			//入力に応じた出力の条件分岐
			if (playerNum == 999){
				
				//強制終了の値999が入力された場合
				System.out.println("　　→999が入力されたためゲームを終了します。");
				System.out.println();
				break;
			} else if (playerNum > 9  || playerNum < 0) {
				
				//入力された値が範囲外の場合
				System.out.println("　　→エラー！！0から9の数字ではありません。");
				System.out.println();
				
			}  else if (playerNum == answerNum) {
				
				//入力された数字が正解数字の場合
				System.out.println("　　→！！大当たり！！");
				System.out.println();
				break;
				
			} else if (playerNum > answerNum) {
		    	
		    	//ヒント
				System.out.println("　　→正解数字は" + playerNum + "より小さいです。");
				System.out.println();
				
			} else {
				
				//ヒント
				System.out.println("　　→正解数字は" + playerNum + "より大きいです");
				System.out.println();
				
			}
		}
		
		//scannerを閉じる
		sc.close();
		
		//終了メッセージ出力
		System.out.println("ゲーム終了");
		
	}

}
