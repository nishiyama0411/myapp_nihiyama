/*　プログラム名：野球ゲームStep2
 *  プログラムの説明：生成した3桁のランダムな数字がユニークか重複しているかをチェックします。
 *  				  チェックした結果はコンソール画面に表示します。
 *  作成者：西山　拓人
 *  作成日：2024年4月15日
 */


package jp.co.f1.app.baseball;

public class BaseBallS02 {

	public static void main(String[] args) {
		
		//タイトル
		System.out.println("---野球ゲームプログラム開始---");
		System.out.println();
		
		//配列answerの宣言
		int[] answer = new int[3];
		
		//for文を用いて配列answerにランダムな3つの変数を代入
		for(int i = 0;i < answer.length;i++) {

			answer[i] = (int)(Math.random()*9);

		}

		//配列answerの出力
		System.out.print("3桁のランダム数字(正解数字)は");
		
		//answerの中身を全て出力
		for(int i = 0;i < answer.length;i++) {
			
			System.out.print(answer[i]);
			
		}
		
		System.out.println("です。");
		
		//重複しているかの条件分岐
		if (answer[0] == answer[1] || answer[0] == answer[2] || answer[1] == answer[2]) {
			System.out.println("⇒重複しています");
		} else {
			System.out.println("⇒ユニークです。");
		}
		
		//終了メッセージ
		System.out.println();
		System.out.println("---野球ゲームプログラム終了---");
		
	}

}
