/*　プログラム名：数当てプログラムStep1
 *  プログラムの説明：プログラマーが「任意で決定した正解数字」と「キーボードから入力した予想数字」を、
 *  				　Eclipseのコンソール画面に表示します。
 *  作成者：西山　拓人
 *  作成日：2024年4月11日
 */


package jp.co.f1.app.numberhit;
import java.util.Scanner;

public class NumberHitS01 {

	public static void main(String[] args) {
		
		//入力受付の準備
		Scanner sc = new Scanner(System.in);
		
		//タイトル表示
		System.out.println("ゲーム開始(正解数字：5");
		System.out.println("");
		
		//正解数字の初期化
		int answerNum = 5;
		
		//入力を促すメッセージ
		System.out.print("　0から9までの予想の数字を入力>>");
		
		//予想数字の入力を受け取り変数num1を初期化
		int playerNum = sc.nextInt();
		
		//予想数字と正解数字の出力
		System.out.println("　　→予想数字は" + playerNum + "です。");
		System.out.println("　　→正解数字は" + answerNum + "です。");
		
		//scannerを閉じる
		sc.close();
		
		//終了メッセージ出力
		System.out.println();
		System.out.println("ゲーム終了");
		
	}

}
