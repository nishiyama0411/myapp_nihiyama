/*　プログラム名：野球ゲームStep1
 *  プログラムの説明：3桁のランダムな数字（正解数字）を生成し、コンソール画面に表示します。
 *  				  3桁の数字は1桁ごとに配列に格納して管理します。
 *  作成者：西山　拓人
 *  作成日：2024年4月15日
 */


package jp.co.f1.app.baseball;

public class BaseBallS01 {

	public static void main(String[] args) {
		
		//タイトル
		System.out.println("---野球ゲームプログラム開始---");
		System.out.println();
		
		//配列answerの宣言
		int[] answer = new int[3];
		
		//for文を用いて配列answerにランダムな3つの変数を代入
		for(int i = 0;i < answer.length;i++) {
			
			answer[i] = (int)(Math.random()*9);
			
		}
		
		//配列answerの出力
		System.out.print("3桁のランダム数字(正解数字)は");
		
		//answerの中身を全て出力
		for(int i = 0;i < answer.length;i++) {
			
			System.out.print(answer[i]);
			
		}
		
		System.out.println("です。");
		
		//終了メッセージ
		System.out.println();
		System.out.println("---野球ゲームプログラム終了---");
		
	}

}
