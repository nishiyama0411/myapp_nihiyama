/*　プログラム名：数当てプログラムStep2
 *  プログラムの説明：「条件文」を利用して「任意で決定した正解の数字」と「キーボードから入力した予想の数字」を比較し、
 *			    		当たりやヒントのメッセージをEclipseのコンソール画面に表示します。
 *  作成者：西山　拓人
 *  作成日：2024年4月11日
 */


package jp.co.f1.app.numberhit;
import java.util.Scanner;

public class NumberHitS02 {

	public static void main(String[] args) {
		
		//入力受付の準備
		Scanner sc = new Scanner(System.in);
		
		//タイトル表示
		System.out.println("ゲーム開始(正解数字：5");
		System.out.println("");
		
		//正解数字の初期化
		int answerNum = 5;
		
		//入力を促すメッセージ
		System.out.print("　0から9までの予想の数字を入力>>");
		
		//予想数字の入力を受け取り変数num1を初期化
		int playerNum = sc.nextInt();
		
		//ヒントの出力の条件分岐
		if (playerNum == answerNum) {
			System.out.println("！！大当たり！！");
		} else if (playerNum >answerNum) {
			System.out.println("正解数字は" + playerNum + "より小さいです。");
		} else {
			System.out.println("正解数字は" + playerNum + "より大きいです");
		}
		
		//scannerを閉じる
		sc.close();
		
		//終了メッセージ出力
		System.out.println();
		System.out.println("ゲーム終了");
		
	}

}
