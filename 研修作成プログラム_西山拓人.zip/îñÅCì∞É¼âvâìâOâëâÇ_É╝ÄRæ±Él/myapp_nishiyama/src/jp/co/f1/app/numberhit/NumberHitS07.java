/*　プログラム名：数当てプログラムStep7
 *  プログラムの説明：JavaAPIのクラスに用意されたメソッドを利用して正解数字をランダムに生成します。
 *   				  プログラムを実行する度にコンソール画面に表示される正解数字が変更されます。
 *  作成者：西山　拓人
 *  作成日：2024年4月17日
 */


package jp.co.f1.app.numberhit;
import java.util.InputMismatchException;
import java.util.Scanner;

public class NumberHitS07 {

	public static void main(String[] args) {

		//入力受付の準備
		Scanner sc = new Scanner(System.in);

		//正解数字に1～9までの乱数を入れて初期化
		int answerNum = (int)(Math.random()*10);

		//予想数字を格納するplayerNumの初期化
		int playerNum = 0;

		//タイトル表示
		System.out.println("ゲーム開始(正解数字：" + answerNum +" )");
		System.out.println("");


		while (true) {
			
			System.out.println();
			
			//文字列が入力された際のエラー処理
			try {
				
				//入力を促すメッセージ
				System.out.print("　0から9までの予想の数字を入力>>");
				
				//予想数字の入力を受け取り変数playerNumに代入
				playerNum = sc.nextInt();
				
			} catch (InputMismatchException e) {
				System.out.println("　　→エラー！！文字が入力されました。");
				//入力ストリームを空にする
				sc.nextLine();
				//エラーなら戻る
				continue;
			} 
			
			//入力に応じた出力の条件分岐
			if (playerNum == 999){
				
				//強制終了の値999が入力された場合
				System.out.println("　　→" + playerNum + "が入力されたためゲームを終了します。");
				System.out.println();
				break;
				
			} else if (playerNum > 9  || playerNum < 0) {
				
				//入力された値が範囲外の場合
				System.out.println("　　→エラー！！0から9の数字ではありません。");
				continue;
			}  else if (playerNum == answerNum) {
				
				//入力された数字が正解数字の場合
				System.out.println("　　→！！大当たり！！");
				break;
				
			} else if (playerNum > answerNum) {
		    	
		    	//ヒント
				System.out.println("　　→正解数字は" + playerNum + "より小さいです。");
				
			} else if (playerNum < answerNum){
				
				//ヒント
				System.out.println("　　→正解数字は" + playerNum + "より大きいです");
				
			}
		}
		
		sc.close();
		
		//終了メッセージ出力
		System.out.println();
		System.out.println("ゲーム終了");
		
	}

}
