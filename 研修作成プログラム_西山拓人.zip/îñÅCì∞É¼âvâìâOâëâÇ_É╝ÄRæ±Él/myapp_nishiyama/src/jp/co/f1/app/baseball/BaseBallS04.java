/*　プログラム名：野球ゲームStep4
 *  プログラムの説明：プレイヤーがキーボードから3桁の数字（予想数字）を入力し、その数字をコンソール画面に表示します。
 *  				  入力した3桁の数字がユニークか重複しているかをチェックし、重複している場合は再度入力を促すメッセージを表示します。
 *  				  入力した3桁の数字がユニークになるまで繰り返します。
 *  作成者：西山　拓人
 *  作成日：2024年4月15日
 */


package jp.co.f1.app.baseball;
import java.util.Scanner;

public class BaseBallS04 {
	

	//重複をチェックするメソッド
	static boolean determine(int[] ary) {
		
		//flagの初期化
		boolean flag;
		
		//重複しているかの条件分岐
		if (ary[0] == ary[1] || ary[0] == ary[2] || ary[1] == ary[2]) {
			System.out.println("⇒重複しています");
			System.out.println();
			flag = false;
		} else {
			System.out.println("⇒ユニークです。");
			System.out.println();
			flag = true;
		}
		
		//重複チェックの結果を返す
		return flag;
	}
	

	public static void main(String[] args) {
		
		//Scannerの準備
		Scanner sc = new Scanner(System.in);
		
		//配列answerの宣言
		int[] answer = new int[3];
		
		//配列playerNumの初期化
		int[] playerNum = new int[3];
		
		
		//タイトル
		System.out.println("---野球ゲームプログラム開始---");
		System.out.println();
		
		
		//配列の中がユニークになるまで無限ループ
		while (true) {
			
			//for文を用いて配列answerにランダムな3つの変数を代入
			for(int i = 0;i < answer.length;i++) {

				answer[i] = (int)(Math.random()*9);

			}

			//配列answerの出力
			System.out.print("3桁のランダム数字(正解数字)は");
			
			//answerの中身を全て出力
			for (int i = 0;i < answer.length;i++) {
				
				System.out.print(answer[i]);
				
			}
			
			System.out.println("です。");
			
			//重複チェック
			boolean flag = determine(answer);
			
			//ユニークな数字なら無限ループを抜ける
			if (flag == true) {
				break;
			}
		}
		
		//受け取った数字がユニークになるまで無限ループ
		while (true) {
			
			
			//予想数字の入力を促すメッセージ
			System.out.print("3桁の数字を入力してください＞＞");
			
			//受け取った数字を格納しておく変数strに代入
			String str =sc.nextLine();
			
			//strの中身を分割し配列playerNumに代入
			for (int i = 0;i < playerNum.length;i++) {
				playerNum[i] = Integer.parseInt(str.substring(i,i+1));
			}
			
			//重複チェック
			boolean flag = determine(playerNum);
			
			//ユニークな数字なら無限ループを抜ける
			if (flag == true) {
				break;
			}
		}
		
		sc.close();
		
		//終了メッセージ
		System.out.println("---野球ゲームプログラム終了---");
		
	}

}
