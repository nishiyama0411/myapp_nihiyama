/*　プログラム名：野球ゲームStep7
 *  プログラムの説明：3桁のランダムな数値（正解数字）とキーボードから入力した3桁の数字（予想数字）を比較し
 *  				　ボール数をカウントします。
 *  				　カウントしたボース数はストライク数と共にコンソール画面に表示します。
 *  
 *  作成者：西山　拓人
 *  作成日：2024年4月15日
 */

package jp.co.f1.app.baseball;
import java.util.Scanner;

public class BaseBallS07 {


	//重複をチェックするメソッド
	static boolean isUniqueArray(int[] ary) {

		//flagをtrueで初期化
		boolean flag = true;

		//重複しているかの条件分岐
		for (int i = 0; i < ary.length; i++) {
			
			for (int j = 0; j < ary.length; j++) {
				//重複してるならfalse
				if (j != i && ary[j] == ary[i]) {
					flag = false;
				}
			}
		}

		//重複チェックの結果を返す
		return flag;
	}


	public static void main(String[] args) {

		//Scannerの準備
		Scanner sc = new Scanner(System.in);

		//配列answerの宣言と領域確保
		int[] answer = new int[3];

		//配列playerNumの宣言と領域確保
		int[] playerNum = new int[3];

		//変数strikeとBcountの宣言
		int strike;
		int ball;

		//変数tryCountの初期化
		int tryCount = 0;

		//タイトル
		System.out.println("---野球ゲームプログラム開始---");
		System.out.println();


		//コンピューターが生み出す３桁の数字が重複しなくなるまでループする
		while (true) {

			//for文を用いて配列answerにランダムな3つの変数を代入
			for(int i = 0;i < answer.length;i++) {

				answer[i] = (int)(Math.random()*10);

			}

			//配列answerの出力
			System.out.print("3桁のランダム数字(正解数字)は");

			//answerの中身を全て出力
			for (int i = 0;i < answer.length;i++) {

				System.out.print(answer[i]);

			}

			System.out.println("です。");

			//重複チェック
			boolean flag = isUniqueArray(answer);


			//ユニークな数字ならループを抜ける
			if (flag) {
				System.out.println("⇒ユニークです。");
				break;
			} else {
				System.out.println("⇒重複しています");
			}
		}

		//3ストライクになるまで無限ループ
		while (true) {

			//受け取った数字がユニークになるまで無限ループ


			//予想数字の入力を促すメッセージ
			System.out.println();
			System.out.print("3桁の数字を入力してください＞＞");

			//受け取った数字を格納しておく変数strに代入
			String str =sc.nextLine();

			//strの中身を分割し配列playerNumに代入
			for (int i = 0;i < playerNum.length;i++) {

				playerNum[i] = Integer.parseInt(str.substring(i,i+1));

			}

			//重複チェック
			boolean flag = isUniqueArray(playerNum);

			//重複していたら戻る
			if (flag) {
				System.out.println("⇒ユニークです。");
			} else {
				System.out.println("⇒重複しています。");
				continue;
			}

			//strikeとBcountをリセット
			strike = 0;
			ball = 0;
			//ストライク数とボール数カウント
			for(int i = 0;i < answer.length;i++) {

				//ストライク
				if (answer[i] == playerNum[i]) {
					strike++;
				}

				//ボール
				for (int j = 0;j < answer.length;j++) {
					if (answer[j] != playerNum[j] && answer[i] == playerNum[j]) {
						ball++;
					}
				}

			}

			//トライ回数を数える
			tryCount++;

			//ストライク数とボール数の出力
			System.out.println("判定：" + strike + "ストライク、" + ball + "ボールです。");

			//3ストライクになったら無限ループを抜ける
			if (strike == 3) {
				break;
			}

		}

		//トライ回数の出力
		System.out.println();
		System.out.println(tryCount + "回トライし、3桁数字を当てました。You Win!!");

		//scannerを閉じる
		sc.close();

		//終了メッセージ
		System.out.println();
		System.out.println("---野球ゲームプログラム終了---");

	}

}
