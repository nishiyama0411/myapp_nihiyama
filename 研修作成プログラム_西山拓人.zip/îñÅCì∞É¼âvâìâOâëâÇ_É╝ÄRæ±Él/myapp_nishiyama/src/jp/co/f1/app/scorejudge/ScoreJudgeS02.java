/*　プログラム名：点数評価プログラムStep2
 *  プログラムの説明：
 *  作成者：西山　拓人
 *  作成日：2024年4月16日
 */

package jp.co.f1.app.scorejudge;
import java.util.Scanner;
public class ScoreJudgeS02 {

	public static void main(String[] args) {
		
		//標準入力の準備
		Scanner sc = new Scanner(System.in);
		
		//タイトル
		System.out.println("---点数評価プログラム開始---");
		System.out.println();
		
		//入力を促すメッセージ
		System.out.print("＞");
		
		//入力を変数scoreに代入
		int score = sc.nextInt();
		
		//点数評価
		if (score < 0 || score > 100) {
			System.out.println("→範囲外の数字が入力されました。再度、0から100までの数字を入力してください。");
	    } else if (score <= 59) {
			System.out.println("→評価Fです。");
		} else if (score <= 69) {
			System.out.println("→評価Dです。");
		} else if (score <= 79) {
			System.out.println("→評価Cです。");
		} else if (score <= 89) {
			System.out.println("→評価Bです。");
		} else if (score <= 100) {
			System.out.println("→評価Aです。");
		}
		
		sc.close();
		//終了画面
		System.out.println();
		System.out.println("---点数評価プログラム終了---");

	}

}
