package game;
import java.util.Scanner;

public class MaruBatu_f22ba067 {

	public static void main(String[] args) {
		  String[][] deta = new String[3][3];
		  
		  deta[0][0] = "０";
		  deta[0][1] = "１";
		  deta[0][2] = "２";
		  deta[1][0] = "３";
		  deta[1][1] = "４";
		  deta[1][2] = "５";
		  deta[2][0] = "６";
		  deta[2][1] = "７";
		  deta[2][2] = "８";
		  
		  
		  for(int x = 0; x < 9;x++) {
			  
		  // マス目の表示
		  for(String[] ary : deta) {
			  for(int i = 0; i < ary.length; i++) {
				  System.out.print(ary[i] + "　");
		     }
			  System.out.println();
		  }
		  
		  //調整
		  System.out.println();
		  
		  // キーボードの入力受付
		  Scanner sc = new Scanner (System.in);

		  //  ○をどこに入れるか
		  System.out.println("○をどのマス目に入れますか");

		  // 入力した文字列を受け取る
		  String msg1 = sc.next();
		  int num1 = Integer.parseInt(msg1);
		  
		  //◯の格納
		  switch (num1) {
		  case 0:
			  deta[0][0] = "○";
			  break;
		  case 1:
			  deta[0][1] = "○";
			  break;
		  case 2:
			  deta[0][2] = "○";
			  break;
		  case 3:
			  deta[1][0] = "○";
			  break;
		  case 4:
			  deta[1][1] = "○";
			  break;
		  case 5:
			  deta[1][2] = "○";
			  break;
		  case 6:
			  deta[2][0] = "○";
			  break;
		  case 7:
			  deta[2][1] = "○";
			  break;
		  case 8:
			  deta[2][2] = "○";
			  break;
		  }
		  if (deta[0][0] == deta[0][1] && deta[0][1] == deta[0][2]) {
			   System.out.println(deta[0][0] + "の勝ちです！");
			   break;
			  } else if (deta[1][0] == deta[1][1] && deta[1][1] == deta[1][2]) {
			   System.out.println(deta[1][0] + "の勝ちです！");
			   break;
			  } else if (deta[2][0] == deta[2][1] && deta[2][1] == deta[2][2]) {
			   System.out.println(deta[2][0] + "の勝ちです！");
			   break;
			  } else if (deta[0][0] == deta[1][0] && deta[1][0] == deta[2][0]) {
			   System.out.println(deta[0][0] + "の勝ちです！");
			   break;
			  } else if (deta[0][1] == deta[1][1] && deta[1][1] == deta[2][1]) {
			   System.out.println(deta[0][1] + "の勝ちです！");
			   break;
			  } else if (deta[0][2] == deta[1][2] && deta[1][2] == deta[2][2]) {
			   System.out.println(deta[1][2] + "の勝ちです！");
			   break;
			  } else if (deta[0][0] == deta[1][1] && deta[1][1] == deta[2][2]) {
			   System.out.println(deta[0][0] + "の勝ちです！");
			   break;
			  } else if (deta[0][2] == deta[1][1] && deta[1][1] == deta[2][0]) {
			   System.out.println(deta[0][2] + "の勝ちです！");
			   break;
			  }
		  // 調整
		  System.out.println("");

		  // 現在の状態を表示
		  for (String[] ary : deta) {
			  for (int i = 0; i < ary.length; i++) {
				  System.out.print(ary[i] + "　");
				  }
			      System.out.println();
		  }

		  // 調整
		  System.out.println("");
		  
		  // ×をどこに入れるか
		  System.out.println("×をどのマス目に入れますか");
		  
		  // 入力した文字列を受け取る
		  String str1 = sc.next();
		  int asc1 = Integer.parseInt(str1);
		  
		  // 回答重複否定
		  if (num1 == asc1) {
			  System.out.println("同じところに入れないでください");
			  return;
		  	  }
		  // ×の格納
		  switch (asc1) {
			 case 0:
				 deta[0][0] = "×";
				 break;
			 case 1:
				 deta[0][1] = "×";
				 break;
			 case 2:
				 deta[0][2] = "×";
				 break;
			 case 3:
				 deta[1][0] = "×";
				 break;
			 case 4:
				 deta[1][1] = "×";
				 break;
			 case 5:
				 deta[1][2] = "×";
				 break;
			 case 6:
				 deta[2][0] = "×";
				 break;
			 case 7:
				 deta[2][1] = "×";
				 break;
			 case 8:
				 deta[2][2] = "×";
				 break;
			 }

		 // 調整
		 System.out.println("");
		 
		 if (deta[0][0] == deta[0][1] && deta[0][1] == deta[0][2]) {
			   System.out.println(deta[0][0] + "の勝ちです！");
			   break;
			  } else if (deta[1][0] == deta[1][1] && deta[1][1] == deta[1][2]) {
			   System.out.println(deta[1][0] + "の勝ちです！");
			   break;
			  } else if (deta[2][0] == deta[2][1] && deta[2][1] == deta[2][2]) {
			   System.out.println(deta[2][0] + "の勝ちです！");
			   break;
			  } else if (deta[0][0] == deta[1][0] && deta[1][0] == deta[2][0]) {
			   System.out.println(deta[0][0] + "の勝ちです！");
			   break;
			  } else if (deta[0][1] == deta[1][1] && deta[1][1] == deta[2][1]) {
			   System.out.println(deta[0][1] + "の勝ちです！");
			   break;
			  } else if (deta[0][2] == deta[1][2] && deta[1][2] == deta[2][2]) {
			   System.out.println(deta[1][2] + "の勝ちです！");
			   break;
			  } else if (deta[0][0] == deta[1][1] && deta[1][1] == deta[2][2]) {
			   System.out.println(deta[0][0] + "の勝ちです！");
			   break;
			  } else if (deta[0][2] == deta[1][1] && deta[1][1] == deta[2][0]) {
			   System.out.println(deta[0][2] + "の勝ちです！");
			   break;
			  }
		  }
		  
	}

}
