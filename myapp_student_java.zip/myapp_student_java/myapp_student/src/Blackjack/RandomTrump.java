package Blackjack;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;


public class RandomTrump {
	List<String> TRUMP_ARR = new ArrayList<String>();

	//コンストラクタ
	public RandomTrump() {
		TRUMP_ARR = new ArrayList<String>(Arrays.asList(
				"h01", "h02", "h03", "h04", "h05", "h06", "h07", "h08", "h09", "h10", "h0J", "h0Q", "h0K",
				"d01", "d02", "d03", "d04", "d05", "d06", "d07", "d08", "d09", "d10", "d0J", "d0Q", "d0K",
				"c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", "c09", "c10", "c0J", "c0Q", "c0K",
				"s01", "s02", "s03", "s04", "s05", "s06", "s07", "s08", "s09", "s10", "s0J", "s0Q", "s0K"
				));
	}

	public String getRandomCard() {
		Random ran = new Random();
		int num = ran.nextInt(TRUMP_ARR.size());

		String ret = TRUMP_ARR.get(num);
		TRUMP_ARR.remove(num);

		return ret;
	}

	public int getCardNumber(String aCard) {
		String target = aCard.substring(1, 3);
		int ret = 0;

		switch (target) {
		case "0J": 
			ret = 11;
			break;

		case "0Q":
			ret = 12;
			break;

		case "0K":
			ret = 13;
			break;

		default:
			ret = Integer.parseInt(target, 10);
		}

		return ret;
	}

	public String getCardMark(String aCard) {
		return aCard.substring(0, 1);
	}

	public String convCardMark(String aCard) {
		String target = aCard.substring(0, 1);
		String ret = "";
		switch (target) {
		case "s": 
			ret = "♠";
			break;

		case "c":
			ret = "♣";
			break;

		case "d":
			ret = "♦";
			break;

		case "h":
			ret = "♥";
			break;

		default:
			ret = "";
		}

		return ret;
	}
}
