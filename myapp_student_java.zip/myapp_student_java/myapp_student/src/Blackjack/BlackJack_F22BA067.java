package Blackjack;
import java.util.Scanner;


public class BlackJack_F22BA067 {

	public static void main(String[] args) {
		

		 // ランダムトランプをインスタンス化
        RandomTrump rt = new RandomTrump();

        // トランプを取得 (ランダムで１枚)
        String result = rt.getRandomCard();
        System.out.println(result);

        // 数字のみにする
        int num = rt.getCardNumber(result);
        System.out.println(num);

        // マークのみにする
        String mark = rt.getCardMark(result);
        System.out.println(mark);

        // マークを変換する
        String mk = rt.convCardMark(result);
        System.out.println(mk);

        //手札の表示
        String card1 = result;
        System.out.println("あなたの手札: " + card1);
        
        //宣言
        int total = 0;

        //21に行くまでサイクル
        while (total < 21) {
            System.out.println("もう1枚トランプを引きますか？ はいorいいえ");
            Scanner sc = new Scanner (System.in);
            String act = sc.next();


            if (act.equalsIgnoreCase("はい")) {
                // もう1枚トランプを引く
                String card2 = rt.getRandomCard();
                total += rt.getCardNumber(card2);

                System.out.println("引いたカード: " + card2);
                System.out.println("合計: " + total);

                // 21を超えているかチェック
                if (total > 21) {
                    System.out.println("バースト！ ゲームオーバー！");
                    break;
                }
            } else if (act.equalsIgnoreCase("いいえ")) {
                System.out.println("終了");
                break;
            } else {
                System.out.println("正しい選択肢を入力してください。");
            }
        }
    }
}